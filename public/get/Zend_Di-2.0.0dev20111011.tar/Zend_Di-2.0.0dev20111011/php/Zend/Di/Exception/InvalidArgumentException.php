<?php
namespace Zend\Di\Exception;

use Zend\Di\Exception;

class InvalidArgumentException 
    extends \InvalidArgumentException 
    implements Exception
{
}
