<?php
namespace Zend\Di\Exception;

use Zend\Di\Exception,
    DomainException;

class ClassNotFoundException extends DomainException implements Exception
{
}
