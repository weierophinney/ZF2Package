<?php

namespace Zend\Authentication\Adapter\Http;

class RuntimeException
    extends \RuntimeException
    implements Exception
{
}