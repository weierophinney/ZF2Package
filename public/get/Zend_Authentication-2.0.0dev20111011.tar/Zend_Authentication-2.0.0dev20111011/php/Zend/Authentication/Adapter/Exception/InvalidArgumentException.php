<?php

namespace Zend\Authentication\Adapter\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Authentication\Adapter\Exception
{
} 