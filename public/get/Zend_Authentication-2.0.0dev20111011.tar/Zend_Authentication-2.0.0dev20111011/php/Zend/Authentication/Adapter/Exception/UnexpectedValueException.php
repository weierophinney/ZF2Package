<?php

namespace Zend\Authentication\Adapter\Exception;

class UnexpectedValueException
    extends \UnexpectedValueException
    implements \Zend\Authentication\Adapter\Exception
{
}