<?php

namespace Zend\Filter\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\Filter\Exception
{
}