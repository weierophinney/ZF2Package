<?php

namespace Zend\Filter\Exception;

class ExtensionNotLoadedException
    extends \RuntimeException
    implements \Zend\Filter\Exception
{
    
}