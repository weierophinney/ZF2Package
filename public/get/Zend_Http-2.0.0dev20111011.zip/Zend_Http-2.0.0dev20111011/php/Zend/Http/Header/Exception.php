<?php

namespace Zend\Http\Header;

interface Exception
{
}
