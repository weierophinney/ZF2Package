<?php

namespace Zend\Http\Exception;

use Zend\Http\Exception;

class RuntimeException 
    extends \RuntimeException 
    implements Exception
{
}
