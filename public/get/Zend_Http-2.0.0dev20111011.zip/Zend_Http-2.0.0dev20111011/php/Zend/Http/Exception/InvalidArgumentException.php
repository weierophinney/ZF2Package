<?php

namespace Zend\Http\Exception;

use Zend\Http\Exception;

class InvalidArgumentException 
    extends \InvalidArgumentException 
    implements Exception
{
}
