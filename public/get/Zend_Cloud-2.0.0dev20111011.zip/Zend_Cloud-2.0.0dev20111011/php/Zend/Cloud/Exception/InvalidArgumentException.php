<?php

namespace Zend\Cloud\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Cloud\Exception
{
    
}