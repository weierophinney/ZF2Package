<?php

namespace Zend\Code\Exception;

use Zend\Code\Exception;

class InvalidArgumentException 
    extends \InvalidArgumentException 
    implements Exception
{
}
