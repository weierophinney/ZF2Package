<?php

namespace Zend\Code\Generator\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\Code\Generator\Exception
{}
