<?php

namespace Zend\Code;

interface Exception
{
}
