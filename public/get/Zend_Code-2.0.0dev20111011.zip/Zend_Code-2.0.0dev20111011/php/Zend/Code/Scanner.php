<?php

namespace Zend\Code;

interface Scanner
{
    /* public static function export($tokens); */
    /* public function toString(); */
}
