<?php

namespace Zend\Date\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\Date\Exception
{
    
}