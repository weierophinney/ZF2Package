<?php

namespace Zend\Validator\Exception;

class ExtensionNotLoadedException
    extends \RuntimeException
    implements \Zend\Validator\Exception
{
    
}
