<?php

namespace Zend\Dojo\View\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\Dojo\View\Exception
{}