<?php

namespace Zend\Validator\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Validator\Exception
{
}
