<?php
namespace Zend\Locale\Exception;

class UnsupportedMethod
    extends \RuntimeException
    implements \Zend\Locale\Exception
{}