<?php

namespace Zend\Config\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Config\Exception
{
}