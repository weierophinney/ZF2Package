<?php
namespace Zend\Di\Exception;

use Zend\Di\Exception;

class RuntimeException extends \RuntimeException implements Exception
{
}
