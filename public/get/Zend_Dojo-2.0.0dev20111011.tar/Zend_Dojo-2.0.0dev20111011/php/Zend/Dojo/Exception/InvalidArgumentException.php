<?php

namespace Zend\Dojo\Exception;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements \Zend\Dojo\Exception
{}