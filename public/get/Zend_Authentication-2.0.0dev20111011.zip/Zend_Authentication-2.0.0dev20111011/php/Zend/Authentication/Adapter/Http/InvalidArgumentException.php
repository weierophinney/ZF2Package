<?php

namespace Zend\Authentication\Adapter\Http;

class InvalidArgumentException
    extends \InvalidArgumentException
    implements Exception
{
}