<?php

namespace Zend\Authentication\Adapter\Exception;

class RuntimeException 
    extends \RuntimeException 
    implements \Zend\Authentication\Adapter\Exception
{

}