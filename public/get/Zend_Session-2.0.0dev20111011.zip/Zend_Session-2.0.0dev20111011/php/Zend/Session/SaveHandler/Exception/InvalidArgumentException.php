<?php

namespace Zend\Session\SaveHandler\Exception;

class InvalidArgumentException
    extends \Zend\Session\Exception\InvalidArgumentException
    implements \Zend\Session\SaveHandler\Exception
{}
