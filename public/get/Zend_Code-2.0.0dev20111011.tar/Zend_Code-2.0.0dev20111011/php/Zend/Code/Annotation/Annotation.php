<?php

namespace Zend\Code\Annotation;

interface Annotation
{
    public function initialize($content);
}