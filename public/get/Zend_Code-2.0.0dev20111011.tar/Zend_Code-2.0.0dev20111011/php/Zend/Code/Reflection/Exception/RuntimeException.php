<?php

namespace Zend\Code\Reflection\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\Code\Reflection\Exception
{}
