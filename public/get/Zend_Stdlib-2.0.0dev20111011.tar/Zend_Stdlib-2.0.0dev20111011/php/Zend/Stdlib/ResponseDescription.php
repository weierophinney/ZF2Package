<?php

namespace Zend\Stdlib;

interface ResponseDescription extends MessageDescription
{

}
